/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1]
/******/ 		var executeModules = data[2];
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fullfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fullfilled = false;
/******/ 			}
/******/ 			if(fullfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	var installedChunks = {
/******/ 		"app": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push(["./src/index.js","common"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/App.js":
/*!********************!*\
  !*** ./src/App.js ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _reactDom = __webpack_require__(/*! react-dom */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _reactRouterDom = __webpack_require__(/*! react-router-dom */ \"./node_modules/react-router-dom/es/index.js\");\n\nvar _app = __webpack_require__(/*! firebase/app */ \"./node_modules/firebase/app/index.js\");\n\nvar firebase = _interopRequireWildcard(_app);\n\n__webpack_require__(/*! firebase/database */ \"./node_modules/firebase/database/index.js\");\n\nvar _Navigation = __webpack_require__(/*! ./components/Navigation/Navigation */ \"./src/components/Navigation/Navigation.js\");\n\nvar _Navigation2 = _interopRequireDefault(_Navigation);\n\nvar _AsyncRoute = __webpack_require__(/*! ./components/AsyncRoute/AsyncRoute */ \"./src/components/AsyncRoute/AsyncRoute.js\");\n\nvar _AsyncRoute2 = _interopRequireDefault(_AsyncRoute);\n\nvar _Loading = __webpack_require__(/*! ./components/Loading/Loading */ \"./src/components/Loading/Loading.js\");\n\nvar _Loading2 = _interopRequireDefault(_Loading);\n\nvar _reactRedux = __webpack_require__(/*! react-redux */ \"./node_modules/react-redux/es/index.js\");\n\nvar _redux = __webpack_require__(/*! redux */ \"./node_modules/redux/es/index.js\");\n\nvar _actions = __webpack_require__(/*! ./actions */ \"./src/actions/index.js\");\n\nfunction _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); } return call && (typeof call === \"object\" || typeof call === \"function\") ? call : self; }\n\nfunction _inherits(subClass, superClass) { if (typeof superClass !== \"function\" && superClass !== null) { throw new TypeError(\"Super expression must either be null or a function, not \" + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }\n\nvar styles = __webpack_require__(/*! ./App.scss */ \"./src/App.scss\");\n\nvar App = function (_React$Component) {\n    _inherits(App, _React$Component);\n\n    function App(props) {\n        _classCallCheck(this, App);\n\n        var _this = _possibleConstructorReturn(this, (App.__proto__ || Object.getPrototypeOf(App)).call(this, props));\n\n        _this.state = {\n            isFetching: _this.props.puns.length > 0 ? false : true\n        };\n        return _this;\n    }\n\n    _createClass(App, [{\n        key: 'componentWillMount',\n        value: function componentWillMount() {\n            var _this2 = this;\n\n            if (this.state.isFetching) {\n                var db = firebase.database();\n                var dbRef = db.ref();\n                var punsRef = dbRef.child('puns');\n                punsRef.once('value', function (snap) {\n                    snap.val().map(function (pun) {\n                        _this2.props.addPun(pun);\n                    });\n                }).then(function () {\n                    _this2.setState({\n                        isFetching: false\n                    });\n                });\n            }\n        }\n    }, {\n        key: 'render',\n        value: function render() {\n            if (this.state.isFetching) {\n                return _react2.default.createElement(\n                    'div',\n                    { className: 'app' },\n                    _react2.default.createElement(_Navigation2.default, null),\n                    _react2.default.createElement(\n                        'div',\n                        { className: 'container' },\n                        _react2.default.createElement(_Loading2.default, { text: 'Loading...' })\n                    )\n                );\n            } else {\n                return _react2.default.createElement(\n                    'div',\n                    { className: 'app' },\n                    _react2.default.createElement(_Navigation2.default, null),\n                    _react2.default.createElement(\n                        'div',\n                        { className: 'container' },\n                        _react2.default.createElement(\n                            _reactRouterDom.Switch,\n                            null,\n                            _react2.default.createElement(_reactRouterDom.Route, { exact: true, path: '/', component: function component(props) {\n                                    return _react2.default.createElement(_AsyncRoute2.default, { props: props, loading: Promise.resolve(__webpack_require__(/*! ./containers/Home/Home */ \"./src/containers/Home/Home.js\")) });\n                                } }),\n                            _react2.default.createElement(_reactRouterDom.Route, { exact: true, path: '/all', component: function component(props) {\n                                    return _react2.default.createElement(_AsyncRoute2.default, { props: props, loading: Promise.resolve(__webpack_require__(/*! ./containers/All/All */ \"./src/containers/All/All.js\")) });\n                                } }),\n                            _react2.default.createElement(_reactRouterDom.Route, { exact: true, path: '/admin', component: function component(props) {\n                                    return _react2.default.createElement(_AsyncRoute2.default, { props: props, loading: Promise.resolve(__webpack_require__(/*! ./containers/Admin/Admin */ \"./src/containers/Admin/Admin.js\")) });\n                                } }),\n                            _react2.default.createElement(_reactRouterDom.Route, { path: '/pun/:id', component: function component(props) {\n                                    return _react2.default.createElement(_AsyncRoute2.default, { props: props, loading: Promise.resolve(__webpack_require__(/*! ./containers/Pun/Pun */ \"./src/containers/Pun/Pun.js\")) });\n                                } }),\n                            _react2.default.createElement(_reactRouterDom.Route, { component: function component(props) {\n                                    return _react2.default.createElement(_AsyncRoute2.default, { props: props, loading: Promise.resolve(__webpack_require__(/*! ./containers/NotFound/NotFound */ \"./src/containers/NotFound/NotFound.js\")) });\n                                } })\n                        )\n                    )\n                );\n            }\n        }\n    }]);\n\n    return App;\n}(_react2.default.Component);\n\nfunction mapStatesToProps(state) {\n    return {\n        puns: state.puns\n    };\n}\n\nfunction matchDispatchToProps(dispatch) {\n    return (0, _redux.bindActionCreators)({\n        addPun: _actions.addPun\n    }, dispatch);\n}\n\nexports.default = (0, _reactRouterDom.withRouter)((0, _reactRedux.connect)(mapStatesToProps, matchDispatchToProps)(App));\n\n//# sourceURL=webpack:///./src/App.js?");

/***/ }),

/***/ "./src/App.scss":
/*!**********************!*\
  !*** ./src/App.scss ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\nmodule.exports = {\"app\":\"app\",\"container\":\"container\"};\n\n//# sourceURL=webpack:///./src/App.scss?");

/***/ }),

/***/ "./src/actions/index.js":
/*!******************************!*\
  !*** ./src/actions/index.js ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nexports.selectPun = exports.removePun = exports.addPun = exports.userLogOut = exports.userLogIn = undefined;\n\nvar _puns = __webpack_require__(/*! ./puns */ \"./src/actions/puns.js\");\n\nvar _pun = __webpack_require__(/*! ./pun */ \"./src/actions/pun.js\");\n\nvar _user = __webpack_require__(/*! ./user */ \"./src/actions/user.js\");\n\nexports.userLogIn = _user.userLogIn;\nexports.userLogOut = _user.userLogOut;\nexports.addPun = _puns.addPun;\nexports.removePun = _puns.removePun;\nexports.selectPun = _pun.selectPun;\n\n//# sourceURL=webpack:///./src/actions/index.js?");

/***/ }),

/***/ "./src/actions/pun.js":
/*!****************************!*\
  !*** ./src/actions/pun.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nvar selectPun = function selectPun(pun) {\n    return {\n        type: 'SELECTED_PUN',\n        payload: pun\n    };\n};\n\nexports.selectPun = selectPun;\n\n//# sourceURL=webpack:///./src/actions/pun.js?");

/***/ }),

/***/ "./src/actions/puns.js":
/*!*****************************!*\
  !*** ./src/actions/puns.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nvar addPun = function addPun(pun) {\n    return {\n        type: 'ADDED_PUN',\n        payload: pun\n    };\n};\n\nvar removePun = function removePun(pun) {\n    return {\n        type: 'REMOVED_PUN',\n        payload: pun\n    };\n};\n\nexports.addPun = addPun;\nexports.removePun = removePun;\n\n//# sourceURL=webpack:///./src/actions/puns.js?");

/***/ }),

/***/ "./src/actions/user.js":
/*!*****************************!*\
  !*** ./src/actions/user.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nvar userLogIn = function userLogIn(user) {\n    return {\n        type: 'USER_LOGGED_IN',\n        payload: user\n    };\n};\n\nvar userLogOut = function userLogOut(user) {\n    return {\n        type: 'USER_LOGGED_OUT',\n        payload: user\n    };\n};\n\nexports.userLogIn = userLogIn;\nexports.userLogOut = userLogOut;\n\n//# sourceURL=webpack:///./src/actions/user.js?");

/***/ }),

/***/ "./src/components/AsyncRoute/AsyncRoute.js":
/*!*************************************************!*\
  !*** ./src/components/AsyncRoute/AsyncRoute.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _Loading = __webpack_require__(/*! ../Loading/Loading */ \"./src/components/Loading/Loading.js\");\n\nvar _Loading2 = _interopRequireDefault(_Loading);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); } return call && (typeof call === \"object\" || typeof call === \"function\") ? call : self; }\n\nfunction _inherits(subClass, superClass) { if (typeof superClass !== \"function\" && superClass !== null) { throw new TypeError(\"Super expression must either be null or a function, not \" + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }\n\nvar AsyncRoute = function (_React$Component) {\n    _inherits(AsyncRoute, _React$Component);\n\n    function AsyncRoute(props) {\n        _classCallCheck(this, AsyncRoute);\n\n        var _this = _possibleConstructorReturn(this, (AsyncRoute.__proto__ || Object.getPrototypeOf(AsyncRoute)).call(this, props));\n\n        _this.state = {\n            loading: true\n        };\n        return _this;\n    }\n\n    _createClass(AsyncRoute, [{\n        key: 'componentDidMount',\n        value: function componentDidMount() {\n            var _this2 = this;\n\n            this.props.loading.then(function (module) {\n                _this2.component = module.default;\n                _this2.setState({\n                    loading: false\n                });\n            });\n        }\n    }, {\n        key: 'render',\n        value: function render() {\n            if (!this.state.loading) {\n                return _react2.default.createElement(this.component, this.props.props);\n            } else {\n                return _react2.default.createElement(_Loading2.default, { text: 'Loading...' });\n            }\n        }\n    }]);\n\n    return AsyncRoute;\n}(_react2.default.Component);\n\nexports.default = AsyncRoute;\n\n//# sourceURL=webpack:///./src/components/AsyncRoute/AsyncRoute.js?");

/***/ }),

/***/ "./src/components/Button/Button.js":
/*!*****************************************!*\
  !*** ./src/components/Button/Button.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _propTypes = __webpack_require__(/*! prop-types */ \"./node_modules/prop-types/index.js\");\n\nvar _propTypes2 = _interopRequireDefault(_propTypes);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar styles = __webpack_require__(/*! ./Button.scss */ \"./src/components/Button/Button.scss\");\n\nvar Button = function Button(_ref) {\n    var onClick = _ref.onClick,\n        text = _ref.text;\n\n    return _react2.default.createElement(\n        'button',\n        { className: 'button', onClick: onClick },\n        text\n    );\n};\n\nButton.propTypes = {\n    onClick: _propTypes2.default.func,\n    text: _propTypes2.default.string\n};\n\nexports.default = Button;\n\n//# sourceURL=webpack:///./src/components/Button/Button.js?");

/***/ }),

/***/ "./src/components/Button/Button.scss":
/*!*******************************************!*\
  !*** ./src/components/Button/Button.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\nmodule.exports = {\"button\":\"button\"};\n\n//# sourceURL=webpack:///./src/components/Button/Button.scss?");

/***/ }),

/***/ "./src/components/Loading/Loading.js":
/*!*******************************************!*\
  !*** ./src/components/Loading/Loading.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar styles = __webpack_require__(/*! ./Loading.scss */ \"./src/components/Loading/Loading.scss\");\n\nvar Loading = function Loading(_ref) {\n  var text = _ref.text;\n  return _react2.default.createElement(\n    'p',\n    { className: 'loading' },\n    text\n  );\n};\n\nexports.default = Loading;\n\n//# sourceURL=webpack:///./src/components/Loading/Loading.js?");

/***/ }),

/***/ "./src/components/Loading/Loading.scss":
/*!*********************************************!*\
  !*** ./src/components/Loading/Loading.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\nmodule.exports = {\"loading\":\"loading\"};\n\n//# sourceURL=webpack:///./src/components/Loading/Loading.scss?");

/***/ }),

/***/ "./src/components/Navigation/Navigation.js":
/*!*************************************************!*\
  !*** ./src/components/Navigation/Navigation.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _reactRouterDom = __webpack_require__(/*! react-router-dom */ \"./node_modules/react-router-dom/es/index.js\");\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); } return call && (typeof call === \"object\" || typeof call === \"function\") ? call : self; }\n\nfunction _inherits(subClass, superClass) { if (typeof superClass !== \"function\" && superClass !== null) { throw new TypeError(\"Super expression must either be null or a function, not \" + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }\n\nvar styles = __webpack_require__(/*! ./Navigation.scss */ \"./src/components/Navigation/Navigation.scss\");\n\nvar Navigation = function (_React$Component) {\n    _inherits(Navigation, _React$Component);\n\n    function Navigation(props) {\n        _classCallCheck(this, Navigation);\n\n        var _this = _possibleConstructorReturn(this, (Navigation.__proto__ || Object.getPrototypeOf(Navigation)).call(this, props));\n\n        _this.state = {\n            isOpen: false\n        };\n\n        _this.openNavigation = _this.openNavigation.bind(_this);\n        _this.closeNavigation = _this.closeNavigation.bind(_this);\n        _this.toggleNavigation = _this.toggleNavigation.bind(_this);\n        return _this;\n    }\n\n    _createClass(Navigation, [{\n        key: 'openNavigation',\n        value: function openNavigation() {\n            this.setState({\n                isOpen: true\n            });\n        }\n    }, {\n        key: 'closeNavigation',\n        value: function closeNavigation() {\n            this.setState({\n                isOpen: false\n            });\n        }\n    }, {\n        key: 'toggleNavigation',\n        value: function toggleNavigation() {\n            if (this.state.isOpen) {\n                this.closeNavigation();\n            } else if (!this.state.isOpen) {\n                this.openNavigation();\n            }\n        }\n    }, {\n        key: 'render',\n        value: function render() {\n            var navClass = this.state.isOpen ? 'nav is-open' : 'nav';\n            var toggleIcon = this.state.isOpen ? 'Close' : 'Open';\n\n            return _react2.default.createElement(\n                'nav',\n                { className: navClass },\n                _react2.default.createElement(\n                    'ul',\n                    { className: 'nav__list' },\n                    _react2.default.createElement(\n                        'li',\n                        { className: 'nav__list-item' },\n                        _react2.default.createElement(\n                            _reactRouterDom.Link,\n                            { to: '/admin', className: 'nav__link', onClick: this.closeNavigation },\n                            'Admin'\n                        )\n                    ),\n                    _react2.default.createElement(\n                        'li',\n                        { className: 'nav__list-item' },\n                        _react2.default.createElement(\n                            _reactRouterDom.Link,\n                            { to: '/', className: 'nav__link', onClick: this.closeNavigation },\n                            'Home'\n                        )\n                    ),\n                    _react2.default.createElement(\n                        'li',\n                        { className: 'nav__list-item' },\n                        _react2.default.createElement(\n                            _reactRouterDom.Link,\n                            { to: '/all', className: 'nav__link', onClick: this.closeNavigation },\n                            'All'\n                        )\n                    )\n                ),\n                _react2.default.createElement(\n                    'div',\n                    { className: 'nav__toggle', onClick: this.toggleNavigation },\n                    toggleIcon\n                )\n            );\n        }\n    }]);\n\n    return Navigation;\n}(_react2.default.Component);\n\nexports.default = Navigation;\n\n//# sourceURL=webpack:///./src/components/Navigation/Navigation.js?");

/***/ }),

/***/ "./src/components/Navigation/Navigation.scss":
/*!***************************************************!*\
  !*** ./src/components/Navigation/Navigation.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\nmodule.exports = {\"nav\":\"nav\",\"is-open\":\"is-open\",\"isOpen\":\"is-open\",\"nav__toggle\":\"nav__toggle\",\"navToggle\":\"nav__toggle\",\"nav__list\":\"nav__list\",\"navList\":\"nav__list\",\"nav__list-item\":\"nav__list-item\",\"navListItem\":\"nav__list-item\",\"nav__link\":\"nav__link\",\"navLink\":\"nav__link\"};\n\n//# sourceURL=webpack:///./src/components/Navigation/Navigation.scss?");

/***/ }),

/***/ "./src/components/Pun/Pun.js":
/*!***********************************!*\
  !*** ./src/components/Pun/Pun.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _propTypes = __webpack_require__(/*! prop-types */ \"./node_modules/prop-types/index.js\");\n\nvar _propTypes2 = _interopRequireDefault(_propTypes);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar styles = __webpack_require__(/*! ./Pun.scss */ \"./src/components/Pun/Pun.scss\");\n\nvar Pun = function Pun(_ref) {\n    var joke = _ref.joke,\n        punchLine = _ref.punchLine;\n\n    return _react2.default.createElement(\n        'div',\n        { className: 'pun' },\n        _react2.default.createElement(Joke, { text: joke }),\n        _react2.default.createElement(PunchLine, { text: punchLine })\n    );\n};\n\nvar Joke = function Joke(_ref2) {\n    var text = _ref2.text;\n    return _react2.default.createElement(\n        'p',\n        { className: 'joke' },\n        text\n    );\n};\nvar PunchLine = function PunchLine(_ref3) {\n    var text = _ref3.text;\n    return _react2.default.createElement(\n        'p',\n        { className: 'punch-line' },\n        text\n    );\n};\n\nPun.propTypes = {\n    joke: _propTypes2.default.string,\n    punchLine: _propTypes2.default.string\n};\n\nexports.default = Pun;\n\n//# sourceURL=webpack:///./src/components/Pun/Pun.js?");

/***/ }),

/***/ "./src/components/Pun/Pun.scss":
/*!*************************************!*\
  !*** ./src/components/Pun/Pun.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\nmodule.exports = {\"pun\":\"pun\",\"joke\":\"joke\",\"punch-line\":\"punch-line\",\"punchLine\":\"punch-line\"};\n\n//# sourceURL=webpack:///./src/components/Pun/Pun.scss?");

/***/ }),

/***/ "./src/components/PunList/PunList.js":
/*!*******************************************!*\
  !*** ./src/components/PunList/PunList.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _reactDom = __webpack_require__(/*! react-dom */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _Pun = __webpack_require__(/*! ../Pun/Pun */ \"./src/components/Pun/Pun.js\");\n\nvar _Pun2 = _interopRequireDefault(_Pun);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar styles = __webpack_require__(/*! ./PunList.scss */ \"./src/components/PunList/PunList.scss\");\n\nvar PunList = function PunList(_ref) {\n    var puns = _ref.puns;\n\n    var punListItems = function punListItems(puns) {\n        return puns.map(function (pun, index) {\n            return punListItem(pun, index);\n        });\n    };\n    var punListItem = function punListItem(pun, index) {\n        return _react2.default.createElement(\n            'li',\n            { className: 'pun-list__item', key: index },\n            _react2.default.createElement(_Pun2.default, { joke: pun.joke, punchLine: pun.punchLine })\n        );\n    };\n\n    return _react2.default.createElement(\n        'ul',\n        { className: 'pun-list' },\n        punListItems(puns)\n    );\n};\n\nexports.default = PunList;\n\n//# sourceURL=webpack:///./src/components/PunList/PunList.js?");

/***/ }),

/***/ "./src/components/PunList/PunList.scss":
/*!*********************************************!*\
  !*** ./src/components/PunList/PunList.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\nmodule.exports = {\"pun-list\":\"pun-list\",\"punList\":\"pun-list\",\"pun-list__item\":\"pun-list__item\",\"punListItem\":\"pun-list__item\"};\n\n//# sourceURL=webpack:///./src/components/PunList/PunList.scss?");

/***/ }),

/***/ "./src/containers/Admin/Admin.js":
/*!***************************************!*\
  !*** ./src/containers/Admin/Admin.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _reactDom = __webpack_require__(/*! react-dom */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _app = __webpack_require__(/*! firebase/app */ \"./node_modules/firebase/app/index.js\");\n\nvar firebase = _interopRequireWildcard(_app);\n\n__webpack_require__(/*! firebase/auth */ \"./node_modules/firebase/auth/index.js\");\n\nvar _Button = __webpack_require__(/*! ../../components/Button/Button */ \"./src/components/Button/Button.js\");\n\nvar _Button2 = _interopRequireDefault(_Button);\n\nvar _reactRedux = __webpack_require__(/*! react-redux */ \"./node_modules/react-redux/es/index.js\");\n\nvar _redux = __webpack_require__(/*! redux */ \"./node_modules/redux/es/index.js\");\n\nvar _actions = __webpack_require__(/*! ../../actions */ \"./src/actions/index.js\");\n\nfunction _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); } return call && (typeof call === \"object\" || typeof call === \"function\") ? call : self; }\n\nfunction _inherits(subClass, superClass) { if (typeof superClass !== \"function\" && superClass !== null) { throw new TypeError(\"Super expression must either be null or a function, not \" + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }\n\nvar styles = __webpack_require__(/*! ./Admin.scss */ \"./src/containers/Admin/Admin.scss\");\n\nvar Admin = function (_React$Component) {\n    _inherits(Admin, _React$Component);\n\n    function Admin(props) {\n        _classCallCheck(this, Admin);\n\n        var _this = _possibleConstructorReturn(this, (Admin.__proto__ || Object.getPrototypeOf(Admin)).call(this, props));\n\n        _this.state = {\n            email: null,\n            password: null\n        };\n\n        _this.handleLogIn = _this.handleLogIn.bind(_this);\n        _this.handleLogOut = _this.handleLogOut.bind(_this);\n        return _this;\n    }\n\n    _createClass(Admin, [{\n        key: 'componentWillMount',\n        value: function componentWillMount() {}\n    }, {\n        key: 'renderLogIn',\n        value: function renderLogIn() {\n            var emailClass = this.state.email === false ? 'input input--error' : 'input';\n            var passwordClass = this.state.password === false ? 'input input--error' : 'input';\n\n            return _react2.default.createElement(\n                'div',\n                { className: 'form' },\n                _react2.default.createElement('input', { type: 'email', placeholder: 'Enter email', className: emailClass, id: 'email' }),\n                _react2.default.createElement('input', { type: 'password', placeholder: 'Enter password', className: passwordClass, id: 'password' })\n            );\n        }\n    }, {\n        key: 'handleLogIn',\n        value: function handleLogIn() {\n            var _this2 = this;\n\n            var email = document.getElementById('email').value;\n            var password = document.getElementById('password').value;\n\n            this.setState({\n                email: null,\n                password: null\n            });\n\n            if (!email) this.setState({ email: false });\n            if (!password) this.setState({ password: false });\n\n            if (!email || !password) return;\n\n            var auth = firebase.auth();\n            auth.signInWithEmailAndPassword(email, password).then(function () {\n                document.getElementById('email').value = '';\n                document.getElementById('password').value = '';\n\n                _this2.props.userLogIn({ name: 'Stefan' });\n            }).catch(function () {\n                document.getElementById('email').value = '';\n                document.getElementById('password').value = '';\n\n                _this2.props.userLogOut();\n            });\n        }\n    }, {\n        key: 'handleLogOut',\n        value: function handleLogOut() {\n            var _this3 = this;\n\n            var auth = firebase.auth();\n            auth.signOut().then(function () {\n                _this3.props.userLogOut();\n            });\n        }\n    }, {\n        key: 'render',\n        value: function render() {\n            var adminLogin = null;\n            var button = null;\n\n            if (!this.props.user.isLoggedIn) {\n                adminLogin = this.renderLogIn();\n                button = _react2.default.createElement(_Button2.default, { text: 'Log in', onClick: this.handleLogIn });\n            } else {\n                adminLogin = null;\n                button = _react2.default.createElement(_Button2.default, { text: 'Log Out', onClick: this.handleLogOut });\n            }\n\n            return _react2.default.createElement(\n                'div',\n                { className: 'admin' },\n                adminLogin,\n                button\n            );\n        }\n    }]);\n\n    return Admin;\n}(_react2.default.Component);\n\nfunction mapStatesToProps(state) {\n    return {\n        user: state.user\n    };\n}\n\nfunction matchDispatchToProps(dispatch) {\n    return (0, _redux.bindActionCreators)({\n        userLogIn: _actions.userLogIn,\n        userLogOut: _actions.userLogOut\n    }, dispatch);\n}\n\nexports.default = (0, _reactRedux.connect)(mapStatesToProps, matchDispatchToProps)(Admin);\n\n//# sourceURL=webpack:///./src/containers/Admin/Admin.js?");

/***/ }),

/***/ "./src/containers/Admin/Admin.scss":
/*!*****************************************!*\
  !*** ./src/containers/Admin/Admin.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\nmodule.exports = {\"admin\":\"admin\",\"input\":\"input\",\"input--error\":\"input--error\",\"inputError\":\"input--error\"};\n\n//# sourceURL=webpack:///./src/containers/Admin/Admin.scss?");

/***/ }),

/***/ "./src/containers/All/All.js":
/*!***********************************!*\
  !*** ./src/containers/All/All.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _reactDom = __webpack_require__(/*! react-dom */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _PunList = __webpack_require__(/*! ../../components/PunList/PunList */ \"./src/components/PunList/PunList.js\");\n\nvar _PunList2 = _interopRequireDefault(_PunList);\n\nvar _reactRedux = __webpack_require__(/*! react-redux */ \"./node_modules/react-redux/es/index.js\");\n\nvar _redux = __webpack_require__(/*! redux */ \"./node_modules/redux/es/index.js\");\n\nvar _actions = __webpack_require__(/*! ../../actions */ \"./src/actions/index.js\");\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); } return call && (typeof call === \"object\" || typeof call === \"function\") ? call : self; }\n\nfunction _inherits(subClass, superClass) { if (typeof superClass !== \"function\" && superClass !== null) { throw new TypeError(\"Super expression must either be null or a function, not \" + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }\n\nvar styles = __webpack_require__(/*! ./All.scss */ \"./src/containers/All/All.scss\");\n\nvar All = function (_React$Component) {\n    _inherits(All, _React$Component);\n\n    function All(props) {\n        _classCallCheck(this, All);\n\n        return _possibleConstructorReturn(this, (All.__proto__ || Object.getPrototypeOf(All)).call(this, props));\n    }\n\n    _createClass(All, [{\n        key: 'render',\n        value: function render() {\n            return _react2.default.createElement(\n                'div',\n                { className: 'all' },\n                _react2.default.createElement(_PunList2.default, { puns: this.props.puns })\n            );\n        }\n    }]);\n\n    return All;\n}(_react2.default.Component);\n\nfunction mapStatesToProps(state) {\n    return {\n        puns: state.puns\n    };\n}\n\nfunction matchDispatchToProps(dispatch) {\n    return (0, _redux.bindActionCreators)({}, dispatch);\n}\n\nexports.default = (0, _reactRedux.connect)(mapStatesToProps, matchDispatchToProps)(All);\n\n//# sourceURL=webpack:///./src/containers/All/All.js?");

/***/ }),

/***/ "./src/containers/All/All.scss":
/*!*************************************!*\
  !*** ./src/containers/All/All.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\n\n//# sourceURL=webpack:///./src/containers/All/All.scss?");

/***/ }),

/***/ "./src/containers/Home/Home.js":
/*!*************************************!*\
  !*** ./src/containers/Home/Home.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _reactDom = __webpack_require__(/*! react-dom */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _Button = __webpack_require__(/*! ../../components/Button/Button */ \"./src/components/Button/Button.js\");\n\nvar _Button2 = _interopRequireDefault(_Button);\n\nvar _Pun = __webpack_require__(/*! ../../components/Pun/Pun */ \"./src/components/Pun/Pun.js\");\n\nvar _Pun2 = _interopRequireDefault(_Pun);\n\nvar _reactRedux = __webpack_require__(/*! react-redux */ \"./node_modules/react-redux/es/index.js\");\n\nvar _redux = __webpack_require__(/*! redux */ \"./node_modules/redux/es/index.js\");\n\nvar _actions = __webpack_require__(/*! ../../actions */ \"./src/actions/index.js\");\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); } return call && (typeof call === \"object\" || typeof call === \"function\") ? call : self; }\n\nfunction _inherits(subClass, superClass) { if (typeof superClass !== \"function\" && superClass !== null) { throw new TypeError(\"Super expression must either be null or a function, not \" + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }\n\nvar styles = __webpack_require__(/*! ./Home.scss */ \"./src/containers/Home/Home.scss\");\n\nvar Home = function (_React$Component) {\n    _inherits(Home, _React$Component);\n\n    function Home(props) {\n        _classCallCheck(this, Home);\n\n        var _this = _possibleConstructorReturn(this, (Home.__proto__ || Object.getPrototypeOf(Home)).call(this, props));\n\n        _this.update = _this.update.bind(_this);\n        return _this;\n    }\n\n    _createClass(Home, [{\n        key: 'componentWillMount',\n        value: function componentWillMount() {\n            this.update();\n        }\n    }, {\n        key: 'update',\n        value: function update() {\n            var _this2 = this;\n\n            var puns = this.props.puns.filter(function (item) {\n                return item !== _this2.props.pun;\n            });\n            var pun = puns[Math.floor(Math.random() * puns.length)];\n\n            this.props.selectPun(pun);\n        }\n    }, {\n        key: 'render',\n        value: function render() {\n            return _react2.default.createElement(\n                'div',\n                { className: 'home' },\n                _react2.default.createElement(_Pun2.default, { joke: this.props.pun.joke, punchLine: this.props.pun.punchLine }),\n                _react2.default.createElement(_Button2.default, { text: 'Tell Me Another', onClick: this.update })\n            );\n        }\n    }]);\n\n    return Home;\n}(_react2.default.Component);\n\nfunction mapStatesToProps(state) {\n    return {\n        puns: state.puns,\n        pun: state.pun\n    };\n}\n\nfunction matchDispatchToProps(dispatch) {\n    return (0, _redux.bindActionCreators)({\n        selectPun: _actions.selectPun\n    }, dispatch);\n}\n\nexports.default = (0, _reactRedux.connect)(mapStatesToProps, matchDispatchToProps)(Home);\n\n//# sourceURL=webpack:///./src/containers/Home/Home.js?");

/***/ }),

/***/ "./src/containers/Home/Home.scss":
/*!***************************************!*\
  !*** ./src/containers/Home/Home.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\nmodule.exports = {\"home\":\"home\"};\n\n//# sourceURL=webpack:///./src/containers/Home/Home.scss?");

/***/ }),

/***/ "./src/containers/NotFound/NotFound.js":
/*!*********************************************!*\
  !*** ./src/containers/NotFound/NotFound.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nfunction _objectDestructuringEmpty(obj) { if (obj == null) throw new TypeError(\"Cannot destructure undefined\"); }\n\nvar styles = __webpack_require__(/*! ./NotFound.scss */ \"./src/containers/NotFound/NotFound.scss\");\n\nvar NotFound = function NotFound(_ref) {\n    _objectDestructuringEmpty(_ref);\n\n    return _react2.default.createElement(\n        'div',\n        { className: 'not-found' },\n        _react2.default.createElement(\n            'p',\n            { className: 'error' },\n            'No puns here.'\n        )\n    );\n};\n\nexports.default = NotFound;\n\n//# sourceURL=webpack:///./src/containers/NotFound/NotFound.js?");

/***/ }),

/***/ "./src/containers/NotFound/NotFound.scss":
/*!***********************************************!*\
  !*** ./src/containers/NotFound/NotFound.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\nmodule.exports = {\"not-found\":\"not-found\",\"notFound\":\"not-found\",\"error\":\"error\"};\n\n//# sourceURL=webpack:///./src/containers/NotFound/NotFound.scss?");

/***/ }),

/***/ "./src/containers/Pun/Pun.js":
/*!***********************************!*\
  !*** ./src/containers/Pun/Pun.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n\tvalue: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _reactDom = __webpack_require__(/*! react-dom */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _PunList = __webpack_require__(/*! ../../components/PunList/PunList */ \"./src/components/PunList/PunList.js\");\n\nvar _PunList2 = _interopRequireDefault(_PunList);\n\nvar _NotFound = __webpack_require__(/*! ../../containers/NotFound/NotFound */ \"./src/containers/NotFound/NotFound.js\");\n\nvar _NotFound2 = _interopRequireDefault(_NotFound);\n\nvar _reactRedux = __webpack_require__(/*! react-redux */ \"./node_modules/react-redux/es/index.js\");\n\nvar _redux = __webpack_require__(/*! redux */ \"./node_modules/redux/es/index.js\");\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); } return call && (typeof call === \"object\" || typeof call === \"function\") ? call : self; }\n\nfunction _inherits(subClass, superClass) { if (typeof superClass !== \"function\" && superClass !== null) { throw new TypeError(\"Super expression must either be null or a function, not \" + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }\n\nvar styles = __webpack_require__(/*! ./Pun.scss */ \"./src/containers/Pun/Pun.scss\");\n\nvar Pun = function (_React$Component) {\n\t_inherits(Pun, _React$Component);\n\n\tfunction Pun(props) {\n\t\t_classCallCheck(this, Pun);\n\n\t\treturn _possibleConstructorReturn(this, (Pun.__proto__ || Object.getPrototypeOf(Pun)).call(this, props));\n\t}\n\n\t_createClass(Pun, [{\n\t\tkey: 'render',\n\t\tvalue: function render() {\n\t\t\tvar _this2 = this;\n\n\t\t\t// Filters list rather than attempting to index out of bounds\n\t\t\tvar punList = this.props.puns.filter(function (pun) {\n\t\t\t\treturn _this2.props.puns.indexOf(pun) == _this2.props.match.params.id;\n\t\t\t});\n\n\t\t\tif (punList.length !== 0) {\n\t\t\t\treturn _react2.default.createElement(\n\t\t\t\t\t'div',\n\t\t\t\t\t{ className: 'all' },\n\t\t\t\t\t_react2.default.createElement(_PunList2.default, { puns: punList })\n\t\t\t\t);\n\t\t\t} else {\n\t\t\t\treturn _react2.default.createElement(_NotFound2.default, null);\n\t\t\t}\n\t\t}\n\t}]);\n\n\treturn Pun;\n}(_react2.default.Component);\n\nfunction mapStatesToProps(state) {\n\treturn {\n\t\tpuns: state.puns\n\t};\n}\n\nfunction matchDispatchToProps(dispatch) {\n\treturn (0, _redux.bindActionCreators)({}, dispatch);\n}\n\nexports.default = (0, _reactRedux.connect)(mapStatesToProps, matchDispatchToProps)(Pun);\n\n//# sourceURL=webpack:///./src/containers/Pun/Pun.js?");

/***/ }),

/***/ "./src/containers/Pun/Pun.scss":
/*!*************************************!*\
  !*** ./src/containers/Pun/Pun.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\n\n//# sourceURL=webpack:///./src/containers/Pun/Pun.scss?");

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar _reactRouterRedux = __webpack_require__(/*! react-router-redux */ \"./node_modules/react-router-redux/es/index.js\");\n\nvar _history = __webpack_require__(/*! history */ \"./node_modules/history/es/index.js\");\n\nvar _redux = __webpack_require__(/*! redux */ \"./node_modules/redux/es/index.js\");\n\nvar _reactRedux = __webpack_require__(/*! react-redux */ \"./node_modules/react-redux/es/index.js\");\n\nvar _reactDom = __webpack_require__(/*! react-dom */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _propTypes = __webpack_require__(/*! prop-types */ \"./node_modules/prop-types/index.js\");\n\nvar _propTypes2 = _interopRequireDefault(_propTypes);\n\nvar _react = __webpack_require__(/*! react */ \"./node_modules/preact-compat/dist/preact-compat.es.js\");\n\nvar _react2 = _interopRequireDefault(_react);\n\nvar _app = __webpack_require__(/*! firebase/app */ \"./node_modules/firebase/app/index.js\");\n\nvar firebase = _interopRequireWildcard(_app);\n\n__webpack_require__(/*! firebase/database */ \"./node_modules/firebase/database/index.js\");\n\nvar _reducers = __webpack_require__(/*! ./reducers */ \"./src/reducers/index.js\");\n\nvar _reducers2 = _interopRequireDefault(_reducers);\n\nvar _App = __webpack_require__(/*! ./App */ \"./src/App.js\");\n\nvar _App2 = _interopRequireDefault(_App);\n\nfunction _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar styles = __webpack_require__(/*! ./index.scss */ \"./src/index.scss\");\n\nvar config = {\n    apiKey: \"AIzaSyDXFaxhOmIfqVN7S2UjhVa3-L8W8-FPIDM\",\n    authDomain: \"very-punny.firebaseapp.com\",\n    databaseURL: \"https://very-punny.firebaseio.com\",\n    projectId: \"very-punny\",\n    storageBucket: \"\",\n    messagingSenderId: \"911938183753\"\n};\nfirebase.initializeApp(config);\n\nif (false) {} else if (false) {}\n\nvar history = (0, _history.createBrowserHistory)();\nvar store = (0, _redux.createStore)(_reducers2.default, (0, _redux.applyMiddleware)((0, _reactRouterRedux.routerMiddleware)(history)));\n\n(0, _reactDom.render)(_react2.default.createElement(\n    _reactRedux.Provider,\n    { store: store },\n    _react2.default.createElement(\n        _reactRouterRedux.ConnectedRouter,\n        { history: history },\n        _react2.default.createElement(_App2.default, null)\n    )\n), document.getElementById('root'));\n\n//# sourceURL=webpack:///./src/index.js?");

/***/ }),

/***/ "./src/index.scss":
/*!************************!*\
  !*** ./src/index.scss ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// removed by extract-text-webpack-plugin\n\n//# sourceURL=webpack:///./src/index.scss?");

/***/ }),

/***/ "./src/reducers/index.js":
/*!*******************************!*\
  !*** ./src/reducers/index.js ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _redux = __webpack_require__(/*! redux */ \"./node_modules/redux/es/index.js\");\n\nvar _reactRouterRedux = __webpack_require__(/*! react-router-redux */ \"./node_modules/react-router-redux/es/index.js\");\n\nvar _user = __webpack_require__(/*! ./user */ \"./src/reducers/user.js\");\n\nvar _user2 = _interopRequireDefault(_user);\n\nvar _puns = __webpack_require__(/*! ./puns */ \"./src/reducers/puns.js\");\n\nvar _puns2 = _interopRequireDefault(_puns);\n\nvar _pun = __webpack_require__(/*! ./pun */ \"./src/reducers/pun.js\");\n\nvar _pun2 = _interopRequireDefault(_pun);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar reducers = (0, _redux.combineReducers)({\n    user: _user2.default,\n    puns: _puns2.default,\n    pun: _pun2.default,\n    routing: _reactRouterRedux.routerReducer\n});\n\nexports.default = reducers;\n\n//# sourceURL=webpack:///./src/reducers/index.js?");

/***/ }),

/***/ "./src/reducers/pun.js":
/*!*****************************!*\
  !*** ./src/reducers/pun.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nfunction _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }\n\nvar initialState = {};\n\nexports.default = function () {\n    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;\n    var action = arguments[1];\n\n    switch (action.type) {\n        case 'SELECTED_PUN':\n            return Object.assign.apply(Object, [{}].concat(_toConsumableArray(state), [action.payload]));\n            break;\n\n        default:\n            return state;\n    }\n};\n\n//# sourceURL=webpack:///./src/reducers/pun.js?");

/***/ }),

/***/ "./src/reducers/puns.js":
/*!******************************!*\
  !*** ./src/reducers/puns.js ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nfunction _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }\n\nvar initialState = [];\n\n// const initialState = [{\n//         \"joke\": \"Did you hear about the guy whose whole left side was cut off?\",\n//         \"punchLine\": \"He's all right now.\"\n//     },\n//     {\n//         \"joke\": \"Why don't some couples go to the gym?\",\n//         \"punchLine\": \"Because some relationships don't work out.\"\n//     },\n//     {\n//         \"joke\": \"I wasn't originally going to get a brain transplant,\",\n//         \"punchLine\": \"but then I changed my mind.\"\n//     },\n//     {\n//         \"joke\": \"Yesterday I accidentally swallowed some food coloring.\",\n//         \"punchLine\": \"The doctor says I'm OK, but I feel like I've dyed a little inside.\"\n//     },\n//     {\n//         \"joke\": \"I wondered why the baseball was getting bigger.\",\n//         \"punchLine\": \"Then it hit me.\"\n//     },\n//     {\n//         \"joke\": \"I'd tell you a chemistry joke\",\n//         \"punchLine\": \"but I know I wouldn't get a reaction.\"\n//     },\n//     {\n//         \"joke\": \"A friend of mine tried to annoy me with bird puns\",\n//         \"punchLine\": \"but I soon realized that toucan play at that game.\"\n//     },\n//     {\n//         \"joke\": \"Have you ever tried to eat a clock?\",\n//         \"punchLine\": \"It's very time consuming.\"\n//     },\n//     {\n//         \"joke\": \"Did you hear about the guy who got hit in the head with a can of soda?\",\n//         \"punchLine\": \"He was lucky it was a soft drink.\"\n//     },\n//     {\n//         \"joke\": \"If there was someone selling drugs in this place,\",\n//         \"punchLine\": \"weed know.\"\n//     }\n// ];\n\nexports.default = function () {\n    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;\n    var action = arguments[1];\n\n    switch (action.type) {\n        case 'ADDED_PUN':\n            return [].concat(_toConsumableArray(state), [action.payload]);\n            break;\n\n        case 'REMOVED_PUN':\n            return state.filter(function (pun) {\n                return state.indexOf(pun) !== state.indexOf(action.payload);\n            });\n            break;\n\n        default:\n            return state;\n    }\n};\n\n//# sourceURL=webpack:///./src/reducers/puns.js?");

/***/ }),

/***/ "./src/reducers/user.js":
/*!******************************!*\
  !*** ./src/reducers/user.js ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nvar initialState = {\n    \"isLoggedIn\": false\n};\n\nexports.default = function () {\n    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;\n    var action = arguments[1];\n\n    switch (action.type) {\n        case 'USER_LOGGED_IN':\n            return Object.assign({}, state, { \"isLoggedIn\": true });\n            break;\n\n        case 'USER_LOGGED_OUT':\n            return Object.assign({}, state, { \"isLoggedIn\": false });\n            break;\n\n        default:\n            return state;\n    }\n};\n\n//# sourceURL=webpack:///./src/reducers/user.js?");

/***/ })

/******/ });