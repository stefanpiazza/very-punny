webpackJsonp([4],{

/***/ 225:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _react = __webpack_require__(2);

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectDestructuringEmpty(obj) { if (obj == null) throw new TypeError("Cannot destructure undefined"); }

var styles = __webpack_require__(234);

var NotFound = function NotFound(_ref) {
    _objectDestructuringEmpty(_ref);

    return _react2.default.createElement(
        'div',
        { className: 'not-found' },
        _react2.default.createElement(
            'p',
            { className: 'error' },
            'No puns here.'
        )
    );
};

exports.default = NotFound;

/***/ }),

/***/ 234:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin
module.exports = {"not-found":"not-found","notFound":"not-found","error":"error"};

/***/ })

});
//# sourceMappingURL=4.js.map